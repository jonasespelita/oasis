act1 = CampusActivities.create_or_update(:id => 9, :date => 'Jan-19-2009', :activity => 'test db/populate', :summary => 'hope this works')
act2 = CampusActivities.create_or_update(:id => 10, :date => 'Jan-21-2009', :activity => 'retest db/populate', :summary => 'yup this works')
