quer1 = Query.create_or_update(:id => 4, :subject => 'populate', :message => 'test db/populate', :user_id => 1)
