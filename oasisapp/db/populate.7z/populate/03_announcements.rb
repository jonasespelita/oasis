ann1 = Announcements.create_or_update(:id => 5, :date_time => 'Jan-21-2009', :announcement => 'retest db/populate', :summary => 'yup this works')
