asess1 = Asessions.create_or_update(:id => 1, :ip_add => '192.168.1.1', :time_out => '2009-01-31 18:37:20.485765', :admin_id => 1)
