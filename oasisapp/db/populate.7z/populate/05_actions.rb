act1 = Actions.create_or_update(:id => 1, :action => 'did something', :asession_id => 1)
